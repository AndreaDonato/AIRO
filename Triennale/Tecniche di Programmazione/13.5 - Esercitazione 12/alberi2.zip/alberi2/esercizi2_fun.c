#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/* Funzioni del tipo astratto */

#include "albbin.h"

/* Funzioni di stampa */

#include "albbin_ascii.h"


/*** Implementazioni funzionali ***/

// Copia di un albero
TipoAlbero copia(TipoAlbero a) {
    if (estVuoto(a))
        return albBinVuoto();
    else
		return creaAlbBin(radice(a),copia(sinistro(a)),copia(destro(a)));
}

// Scambia sottoalberi
TipoAlbero scambiaSottoAlberi(TipoAlbero a) {
    if (estVuoto(a))
        return albBinVuoto();
    else
		return creaAlbBin(radice(a), 
            scambiaSottoAlberi(destro(a)), 
            scambiaSottoAlberi(sinistro(a)));
}


// Verifica se nodo è una foglia
bool foglia(TipoAlbero a) {
    return (!estVuoto(a) && estVuoto(sinistro(a)) && estVuoto(destro(a)));
}

// Rimuovi foglie di un albero 
// Se a è una foglia, restituisce albero vuoto
TipoAlbero rimuoviFoglie(TipoAlbero a) {
    if (estVuoto(a))
        return albBinVuoto();
    else if (foglia(a))
        return albBinVuoto();
    else {
        return creaAlbBin(radice(a),
            rimuoviFoglie(sinistro(a)),
            rimuoviFoglie(destro(a)));
    }
}

// Aggiunge una copia di b come sottoalbero estremo a sinistra
// Se a è vuoto, copia b.
TipoAlbero aggiungiSinistra(TipoAlbero a, TipoAlbero b) {
    if (estVuoto(a))
        return copia(b);
    else
        return creaAlbBin(radice(a),
            aggiungiSinistra(sinistro(a),b), 
            copia(destro(a)) );
}

// Aggiunge una copia di b come sottoalbero estremo a destra
// Se a è vuoto, copia b.
TipoAlbero aggiungiDestra(TipoAlbero a, TipoAlbero b) {
    if (estVuoto(a))
        return copia(b);
    else
        return creaAlbBin(radice(a),
            copia(sinistro(a)),
            aggiungiDestra(destro(a),b) );
}






// Restituisce la foglia estrema sinistra di a
TipoAlbero fogliaSinistra(TipoAlbero a){
  if (estVuoto(a))
    return albBinVuoto();
  else if (!estVuoto(sinistro(a)))
    return fogliaSinistra(sinistro(a));
  else if (!estVuoto(destro(a)))
    return fogliaSinistra(destro(a));
  else // a la foglia estrema a sinistra
    return a;
}


// Inserisce foglia che diventerà estrema sinistra
TipoAlbero inserisciFogliaSinistra(TipoAlbero a, TipoInfoAlbero e){
    if (estVuoto(a)) {
        return creaAlbBin(e,albBinVuoto(),albBinVuoto());
    }
    else {
        return creaAlbBin(radice(a),
                inserisciFogliaSinistra(sinistro(a),e),
                copia(destro(a)) );
    }
}

// Inserisce foglia che diventerà estrema destra
TipoAlbero inserisciFogliaDestra(TipoAlbero a, TipoInfoAlbero e){
    if (estVuoto(a)) {
        return creaAlbBin(e,albBinVuoto(),albBinVuoto());
    }
    else {
        return creaAlbBin(radice(a),
                copia(sinistro(a)),
                inserisciFogliaDestra(destro(a),e) );
    }
}


// Elimina sotto-albero con info e (funzionale)
// Se a è una foglia con info e, restituisce albero vuoto
TipoAlbero eliminaSottoAlberoInfo(TipoAlbero a, TipoInfoAlbero e) {
    if (estVuoto(a))
        return albBinVuoto();
    else if (radice(a)==e)
        return albBinVuoto();
    else {
        return creaAlbBin(radice(a),
                eliminaSottoAlberoInfo(sinistro(a),e),
                eliminaSottoAlberoInfo(destro(a),e) );
    }
}


// Inserisci foglia con informazione e in posizione data dal percorso p
TipoAlbero inserisciFogliaInPosizione(TipoAlbero a, TipoInfoAlbero e,
                                const char* p){
    if (estVuoto(a)) {
        return creaAlbBin(e,albBinVuoto(),albBinVuoto());
    }
    else if (*p=='\0')  // percorso termina in un nodo dell'albero
      return copia(a);
    else if (*p=='s') {
      return creaAlbBin(radice(a),
                inserisciFogliaInPosizione(sinistro(a), e, p+1),
                copia(destro(a)) );
    }
    else if (*p=='d') {
      return creaAlbBin(radice(a),
                copia(sinistro(a)),
                inserisciFogliaInPosizione(destro(a), e, p+1) );
    }
    else { 
        printf("Percorso %s errato!!!\n", p);
        return albBinVuoto();
    } 
}

// Inserisci nodo con informazione e in posizione data dal percorso p
// mettendo il sottoalbero corrispondente al nodo corrente
// a sinistra o a destra, a seconda del valore di f
TipoAlbero inserisciInPosizione(TipoAlbero a, TipoInfoAlbero e,
                          const char* p, char f)
{
    if (estVuoto(a)) {
        return creaAlbBin(e,albBinVuoto(),albBinVuoto());
    }
    else if (*p=='\0') { // posizione in cui inserire il nodo
    	if (f == 'd') {
            return creaAlbBin(e,albBinVuoto(),copia(a));
    	}
    	else {
            return creaAlbBin(e,copia(a),albBinVuoto());
        }
  	}
  	else if (*p=='s') {
        return creaAlbBin(radice(a),
            inserisciInPosizione(sinistro(a), e, p+1, f),
            copia(destro(a)) );
    }
    else if (*p=='d') {
        return creaAlbBin(radice(a),
            copia(sinistro(a)),
            inserisciInPosizione(destro(a), e, p+1, f) );
    }
    else { 
        printf("Percorso %s errato!!!\n", p);
        return albBinVuoto();
    } 
}

// Elimina il primo nodo (visita in pre-ordine) che contiene
// l'informazione e, effettuando la seguente operazione sui
// sotto-alberi del nodo da eliminare:
// il sottoalbero destro del nodo da eliminare viene posto come
// sottoalbero sinistro della foglia piu' a sinistra di tale nodo

TipoAlbero eliminaNodo(TipoAlbero a, TipoInfoAlbero e) {
  if (estVuoto(a)) {
    return albBinVuoto();
  }
  else if (radice(a) == e) {
    // il sottoalbero destro di a diventa il
    // sottoalbero sinistro della foglia piu' a sinistra di a
    // e il nodo a non viene inserito nell'albero di output
    return aggiungiSinistra(sinistro(a),destro(a));
  }
  else
    return creaAlbBin(radice(a),
            eliminaNodo(sinistro(a),e),
            eliminaNodo(destro(a),e) );
}



int main() {

    srand(time(0)); // set random seed

    printf("Random albero a1\n");
    TipoAlbero a1 = randomAlbero(5);
    stampaAlberoASCII("a1",a1);

    printf("Scambia sottoalberi a1\n");
    stampaAlberoASCII("scambiaSottoAlberi(a1)",scambiaSottoAlberi(a1));

    printf("Random albero a2\n");
    TipoAlbero a2 = randomAlbero(5);
    stampaAlberoASCII("a2",a2);

    printf("Scambia sottoalberi a2\n");
    stampaAlberoASCII("scambiaSottoAlberi(a2)",scambiaSottoAlberi(a2));

    printf("Copia a2\n");
    TipoAlbero a3 = copia(a2);
    stampaAlberoASCII("a3",a3);

    printf("Rimuovi foglie a3\n");
    a3 = rimuoviFoglie(a3);
    stampaAlberoASCII("a3",a3);

    printf("Rimuovi foglie a3\n");
    a3 = rimuoviFoglie(a3);
    stampaAlberoASCII("a3",a3);

    printf("Aggiungi sinistra a1\n");
    a3 = aggiungiSinistra(a3,a1);
    stampaAlberoASCII("a3",a3);

    printf("Aggiungi destra a2\n");
    a3 = aggiungiDestra(a3,a2);
    stampaAlberoASCII("a3",a3);

    printf("Copia a3\n");
    TipoAlbero a4 = copia(a3);
    stampaAlberoASCII("a4",a4);

    printf("Rimuovi tutti i nodi\n");
    while (!estVuoto(a4)) {
        a4 = rimuoviFoglie(a4);
    }
    stampaAlberoASCII("a4",a4);

    printf("Copia a2\n");
    TipoAlbero a5 = copia(a2);
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglia sinistra a5\n");
    a5 = inserisciFogliaSinistra(a5,'S');
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglia destra a5\n");
    a5 = inserisciFogliaDestra(a5,'D');
    stampaAlberoASCII("a5",a5);

    printf("Elimina sottoalberi a5 con valori P,Q,R,S\n");
    a5 = eliminaSottoAlberoInfo(a5,'P');
    a5 = eliminaSottoAlberoInfo(a5,'Q');
    a5 = eliminaSottoAlberoInfo(a5,'R');
    a5 = eliminaSottoAlberoInfo(a5,'S');
    stampaAlberoASCII("a5",a5);

    printf("Elimina sottoalberi a5 con valori X,Y,Z\n");
    a5 = eliminaSottoAlberoInfo(a5,'X');
    a5 = eliminaSottoAlberoInfo(a5,'Y');
    a5 = eliminaSottoAlberoInfo(a5,'Z');
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglie a5 P,Q,R,S\n");
    a5 = inserisciFogliaInPosizione(a5,'P',"ss");
    a5 = inserisciFogliaInPosizione(a5,'Q',"sd");
    a5 = inserisciFogliaInPosizione(a5,'R',"ds");
    a5 = inserisciFogliaInPosizione(a5,'S',"dd");
    stampaAlberoASCII("a5",a5);

    printf("Inserisci in posizione a5 X,Y,Z\n");
    a5 = inserisciInPosizione(a5, 'X', "d", 's');
    a5 = inserisciInPosizione(a5, 'Y', "d", 'd');
    a5 = inserisciInPosizione(a5, 'Z', "ds", 'd');
    stampaAlberoASCII("a5",a5);

    printf("Elimina nodo a5 P\n");
    a5 = eliminaNodo(a5, 'P');
    stampaAlberoASCII("a5",a5);

    printf("Elimina nodo a5 X\n");
    a5 = eliminaNodo(a5, 'X');
    stampaAlberoASCII("a5",a5);

}
