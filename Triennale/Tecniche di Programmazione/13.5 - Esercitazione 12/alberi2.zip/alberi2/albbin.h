#pragma once

#include <stdio.h>
#include <stdlib.h>

// Tipo info dell'albero
typedef char TipoInfoAlbero;

// Valore di errore
const TipoInfoAlbero ERRORE_InfoAlbBin='*';

// Albero con strutture collegate
typedef struct StructAlbero {
  TipoInfoAlbero info;
  struct StructAlbero* destro;
  struct StructAlbero* sinistro;
} TipoNodoAlbero;

typedef TipoNodoAlbero* TipoAlbero;

// Funzioni del tipo astratto (implementazione funzionale)

TipoAlbero albBinVuoto();
TipoAlbero creaAlbBin(TipoInfoAlbero info, TipoAlbero sx, TipoAlbero dx);
bool estVuoto(TipoAlbero a);
TipoInfoAlbero radice(TipoAlbero a);
TipoAlbero sinistro(TipoAlbero a);
TipoAlbero destro(TipoAlbero a);

// Funzioni del tipo astratto (implementazione con side-effect)

void albBinVuoto(TipoAlbero *a);
void creaAlbBin(TipoAlbero *a, TipoInfoAlbero info, TipoAlbero *sx, TipoAlbero *dx);
void modAlbBin(TipoAlbero *a, TipoInfoAlbero info, TipoAlbero *sx, TipoAlbero *dx);
bool estVuoto(TipoAlbero *a);
TipoInfoAlbero radice(TipoAlbero *a);
TipoAlbero * sinistro(TipoAlbero *a);
TipoAlbero * destro(TipoAlbero *a);


// Funzioni ausiliarie (implementazione funzionale)

void stampaInfoAlbero(TipoInfoAlbero c);
void stringaInfoAlbero(char *s, TipoInfoAlbero c);
void stampaAlbero(const char* astr, TipoAlbero a);
TipoAlbero leggiAlbero(char *nome_file);
TipoAlbero randomAlbero(int size);

// Funzioni ausiliarie (implementazione con side-effect)

void randomAlbero(TipoAlbero *a, int size, int maxlivello=5);

