#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/* Funzioni del tipo astratto */

#include "albbin.h"

/* Funzioni di stampa */

#include "albbin_ascii.h"


/*** Implementazioni con side-effect ***/

// Passaggio di parametri tramite puntatore

/*
  In tutte le funzioni, si assume che a sia sempre != NULL
  ovvero che sia sempre un puntatore valido ad un albero
  (eventualmente vuoto, ovvero *a == NULL)

  Si può aggiungere un eventuale controllo
  che la funzione sia chiamata correttamente:

  if ( a==NULL ) {
    printf("ERRORE\n");
    return;
  }
*/




// Copia l'albero b in a
void copia(TipoAlbero *a, TipoAlbero *b) {
    if (estVuoto(b))
        albBinVuoto(a);
    else {
        TipoAlbero s,d;
        copia(&s,sinistro(b));
        copia(&d,destro(b));
		creaAlbBin(a,radice(b),&s,&d);
    }
}

// Scambia tutti i sotto-alberi
void scambiaSottoAlberi(TipoAlbero *a) {
    if (!estVuoto(a)) {
        scambiaSottoAlberi(sinistro(a));
        scambiaSottoAlberi(destro(a));
        modAlbBin(a,radice(a),destro(a),sinistro(a));
    }
}

// Elimina tutti i nodi deallocando la memoria
void dealloca(TipoAlbero *a) {
    if (!estVuoto(a)) {
        dealloca(sinistro(a));
        dealloca(destro(a));
        free(*a);
        albBinVuoto(a);
    }
}


// Aggiunge una copia di b come sottoalbero estremo a sinistra
// Se a è vuoto, copia b.
void aggiungiSinistra(TipoAlbero *a, TipoAlbero *b) {
    if (estVuoto(a))
        *a=*b;
    else
        aggiungiSinistra(sinistro(a), b);
}

// Analogo al precedente, considerando il sottoalbero estremo a destra
void aggiungiDestra(TipoAlbero *a, TipoAlbero *b) {
    if (estVuoto(a))
        *a=*b;
    else
        aggiungiDestra(destro(a), b);
}

// Verifica che il nodo sia una foglia
bool foglia(TipoAlbero *a) {
    return (estVuoto(sinistro(a)) && estVuoto(destro(a)));
}


// Elimina foglie di un albero (side-effect)
// Se a è una foglia, diventa albero vuoto
void rimuoviFoglie(TipoAlbero *a) {
    if (estVuoto(a))
        return;
    else if (foglia(a))
        dealloca(a);
    else {
        rimuoviFoglie(sinistro(a));
        rimuoviFoglie(destro(a));
    }
}


// Inserisce foglia che diventerà estrema sinistra
void inserisciFogliaSinistra(TipoAlbero* a, TipoInfoAlbero e){
    if (estVuoto(a)) {
        TipoAlbero s,d;
        albBinVuoto(&s); albBinVuoto(&d);
        creaAlbBin(a,e,&s,&d);
    }
    else
      inserisciFogliaSinistra(sinistro(a), e);
}

// Inserisce foglia che diventerà estrema destra
void inserisciFogliaDestra(TipoAlbero* a, TipoInfoAlbero e){
    if (estVuoto(a)) {
        TipoAlbero s,d;
        albBinVuoto(&s); albBinVuoto(&d);
        creaAlbBin(a,e,&s,&d);
    }
    else
      inserisciFogliaDestra(destro(a), e);
}



// Elimina sotto-albero con info e (side-effect)
// Se a è una foglia con info e, diventa albero vuoto
void eliminaSottoAlberoInfo(TipoAlbero *a, TipoInfoAlbero e) {
    if (estVuoto(a))
        return;
    else if (radice(a)==e)
        dealloca(a);
    else {
        eliminaSottoAlberoInfo(sinistro(a),e);
        eliminaSottoAlberoInfo(destro(a),e);
    }
}

// Inserisci foglia con informazione e in posizione data dal percorso p
void inserisciFogliaInPosizione(TipoAlbero* a, TipoInfoAlbero e,
                                const char* p){
    if (estVuoto(a)) {
        TipoAlbero s,d;
        albBinVuoto(&s); albBinVuoto(&d);
        creaAlbBin(a,e,&s,&d);
    }
    else if (*p=='\0')  // percorso termina in un nodo dell'albero
      return;
    else if (*p=='s')
      inserisciFogliaInPosizione(sinistro(a), e, p+1);
    else if (*p=='d')
      inserisciFogliaInPosizione(destro(a), e, p+1);
}


///////////////////////////

// Inserisci nodo con informazione e in posizione data dal percorso p
// mettendo il sottoalbero corrispondente al nodo corrente
// a sinistra o a destra, a seconda del valore di f
void inserisciInPosizione(TipoAlbero* a, TipoInfoAlbero e,
                          const char* p, char f)
{
    if (estVuoto(a)) {
        TipoAlbero s,d;
        albBinVuoto(&s); albBinVuoto(&d);
        creaAlbBin(a,e,&s,&d);
    }
    else if (*p=='\0') {
    	if (f == 'd'){
            TipoAlbero s,*d;
            albBinVuoto(&s); d=a;
      		creaAlbBin(a,e,&s,d);
    	}
    	else {
            TipoAlbero *s,d;
            albBinVuoto(&d); s=a;
      		creaAlbBin(a,e,s,&d);
        }
  	}
  	else if (*p=='s')
        inserisciInPosizione(sinistro(a), e, p+1, f);
    else if (*p=='d')
    	inserisciInPosizione(destro(a), e, p+1, f);
}


// Elimina il primo nodo (visita in pre-ordine) che contiene
// l'informazione e, effettuando la seguente operazione sui
// sotto-alberi del nodo da eliminare:
// il sottoalbero destro del nodo da eliminare viene posto come
// sottoalbero sinistro della foglia piu' a sinistra di tale nodo
// Restituisce true se viene effettuata l'operazione di eliminazione,
// false altrimenti.

bool eliminaNodo(TipoAlbero* a, TipoInfoAlbero e) {
  if (estVuoto(a)) {
    return false;
  }
  else if (radice(a) == e) {
    // il sottoalbero destro di a diventa il
    // sottoalbero sinistro della foglia piu' a sinistra di a
    if (!estVuoto(destro(a))) {
      aggiungiSinistra(sinistro(a),destro(a));
    }
    // Elimina il nodo *a
    TipoAlbero n = *a;
    *a = *sinistro(a);
    free(n); // Dealloca il nodo eliminato
    return true;
  }
  else
    return (eliminaNodo(sinistro(a),e) || eliminaNodo(destro(a),e));
}




int main() {

    srand(time(0)); // set random seed

    printf("Random albero a1\n");
    TipoAlbero a1;
    randomAlbero(&a1,5);
    stampaAlberoASCII("a1",a1);

    printf("Scambia sottoalberi a1\n");
    scambiaSottoAlberi(&a1);
    stampaAlberoASCII("a1",a1);

    printf("Random albero a2\n");
    TipoAlbero a2;
    randomAlbero(&a2,5);
    stampaAlberoASCII("a2",a2);

    printf("Scambia sottoalberi a2\n");
    scambiaSottoAlberi(&a2);
    stampaAlberoASCII("a2",a2);

    printf("Copia a2\n");
    TipoAlbero a3;
    copia(&a3,&a2);
    stampaAlberoASCII("a3",a3);

    printf("Rimuovi foglie a3\n");
    rimuoviFoglie(&a3);
    stampaAlberoASCII("a3",a3);

    printf("Rimuovi foglie a3\n");
    rimuoviFoglie(&a3);
    stampaAlberoASCII("a3",a3);

    printf("Aggiungi sinistra a1\n");
    aggiungiSinistra(&a3,&a1);
    stampaAlberoASCII("a3",a3);

    printf("Aggiungi destra a2\n");
    aggiungiDestra(&a3,&a2);
    stampaAlberoASCII("a3",a3);


    printf("Copia a3\n");
    TipoAlbero a4;
    copia(&a4,&a3);
    stampaAlberoASCII("a4",a4);

    printf("Rimuovi tutti i nodi\n");
    while (!estVuoto(&a4)) {
        rimuoviFoglie(&a4);
    }
    stampaAlberoASCII("a4",a4);

    printf("Copia a2\n");
    TipoAlbero a5;
    copia(&a5,&a2);
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglia sinistra a5\n");
    inserisciFogliaSinistra(&a5,'S');
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglia destra a5\n");
    inserisciFogliaDestra(&a5,'D');
    stampaAlberoASCII("a5",a5);

    printf("Elimina sottoalberi a5 con valori P,Q,R,S\n");
    eliminaSottoAlberoInfo(&a5,'P');
    eliminaSottoAlberoInfo(&a5,'Q');
    eliminaSottoAlberoInfo(&a5,'R');
    eliminaSottoAlberoInfo(&a5,'S');
    stampaAlberoASCII("a5",a5);

    printf("Elimina sottoalberi a5 con valori X,Y,Z\n");
    eliminaSottoAlberoInfo(&a5,'X');
    eliminaSottoAlberoInfo(&a5,'Y');
    eliminaSottoAlberoInfo(&a5,'Z');
    stampaAlberoASCII("a5",a5);

    printf("Inserisci foglie a5 P,Q,R,S\n");
    inserisciFogliaInPosizione(&a5,'P',"ss");
    inserisciFogliaInPosizione(&a5,'Q',"sd");
    inserisciFogliaInPosizione(&a5,'R',"ds");
    inserisciFogliaInPosizione(&a5,'S',"dd");
    stampaAlberoASCII("a5",a5);

    printf("Inserisci in posizione a5 X,Y,Z\n");
    inserisciInPosizione(&a5, 'X', "d", 's');
    inserisciInPosizione(&a5, 'Y', "d", 'd');
    inserisciInPosizione(&a5, 'Z', "ds", 'd');
    stampaAlberoASCII("a5",a5);

    printf("Elimina nodo a5 P\n");
    eliminaNodo(&a5, 'P');
    stampaAlberoASCII("a5",a5);

    printf("Elimina nodo a5 X\n");
    eliminaNodo(&a5, 'X');
    stampaAlberoASCII("a5",a5);


    dealloca(&a5);
    dealloca(&a4);
    dealloca(&a3);
    dealloca(&a2);
    dealloca(&a1);

}
