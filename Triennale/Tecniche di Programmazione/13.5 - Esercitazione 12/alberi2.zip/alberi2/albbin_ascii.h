#pragma once

#include "albbin.h"

typedef TipoInfoAlbero TipoInfoCoda;

void stampaAlberoASCII(const char* astr, TipoAlbero a);


